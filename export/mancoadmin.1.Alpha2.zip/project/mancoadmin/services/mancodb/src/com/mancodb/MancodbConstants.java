
package com.mancodb;



/**
 *  Query names for service "mancodb"
 *  10/06/2014 16:56:02
 * 
 */
public class MancodbConstants {

    public final static String getUsersByIdQueryName = "getUsersById";

}

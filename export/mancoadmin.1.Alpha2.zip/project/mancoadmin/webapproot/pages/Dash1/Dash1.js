dojo.declare("Dash1", wm.Page, {
	start: function() {
		
	},
	"preferredDevice": "desktop",

	_end: 0
});